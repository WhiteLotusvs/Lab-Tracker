<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Users</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <h1>Edit Users</h1>
    <table>
        <tr>
            <th>Username</th>
            <th>Password</th>
            <th>Student ID</th>
            <th>Actions</th>
        </tr>
        <?php
        $users = json_decode(file_get_contents('data/users.json'), true);
        foreach ($users as $user) {
            echo "<tr>
                    <td><input type='text' name='username' value='{$user['username']}'></td>
                    <td><input type='password' name='password' value='{$user['password']}'></td>
                    <td><input type='text' name='student_id' value='{$user['student_id']}'></td>
                    <td>
                        <button onclick='editUser(\"{$user['username']}\")'>Edit</button>
                        <button onclick='deleteUser(\"{$user['username']}\")'>Delete</button>
                    </td>
                  </tr>";
        }
        ?>
    </table>
    <nav>
        <ul>
            <li><a href="index.html">Home</a></li>
            <li><a href="register.php">Register</a></li>
            <li><a href="admin.php">Admin</a></li>
            <li><a href="view_users.php">View Users</a></li>
            <li><a href="view_schedule.php">View Schedule</a></li>
            <li><a href="lab_tracker.php">Lab Tracker</a></li>
        </ul>
    </nav>
</body>
<script src="js/scripts.js"></script>
</html>
