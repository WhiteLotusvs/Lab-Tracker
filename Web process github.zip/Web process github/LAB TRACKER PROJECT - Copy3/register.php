<?php
function validatePassword($password) {
    $regex = "/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{6,20}$/";
    return preg_match($regex, $password);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $student_id = $_POST['student_id'];

    if (!validatePassword($password)) {
        echo "<script>alert('Password does not meet the requirements.');</script>";
    } else {
        $users = json_decode(file_get_contents('data/users.json'), true);
        $new_user = array("username" => $username, "password" => $password, "student_id" => $student_id);
        array_push($users, $new_user);
        file_put_contents('data/users.json', json_encode($users));
        echo "<script>alert('Registration successful!');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Register</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <div class="header">
        <h1>Register</h1>
    </div>
    <form method="post" action="register.php">
        <label for="username">Username (6 letters):</label>
        <input type="text" id="username" name="username" required><br>
        <label for="password">Password (6 characters, 1 uppercase, 1 lowercase, 1 special character (*%#$!)):</label>
        <input type="password" id="password" name="password" required><br>
        <label for="student_id">Student ID (7 digits):</label>
        <input type="text" id="student_id" name="student_id" required><br>
        <button type="submit">Register</button>
    </form>
</body>
</html>
