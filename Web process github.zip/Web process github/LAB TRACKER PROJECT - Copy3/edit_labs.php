<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Labs</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <h1>Edit Labs</h1>
    <form id="editLabForm">
        <label for="courseName">Course Name:</label>
        <input type="text" id="courseName" name="courseName"><br>
        <label for="courseSection">Course Section:</label>
        <input type="text" id="courseSection" name="courseSection"><br>
        <label for="instructorName">Instructor Name:</label>
        <input type="text" id="instructorName" name="instructorName"><br>
        <label for="labTime">Lab Time:</label>
        <input type="text" id="labTime" name="labTime"><br>
        <button type="button" onclick="addLab()">Add Lab</button>
    </form>

    <h2>Active Labs</h2>
    <table id="activeLabsTable">
        <?php
        $labs = json_decode(file_get_contents('data/labs.json'), true);
        foreach ($labs as $lab) {
            echo "<tr>
                    <td>{$lab['courseName']}</td>
                    <td>{$lab['courseSection']}</td>
                    <td>{$lab['instructorName']}</td>
                    <td>{$lab['labTime']}</td>
                    <td>
                        <button onclick='editLab(\"{$lab['courseName']}\")'>Edit</button>
                        <button onclick='deleteLab(\"{$lab['courseName']}\")'>Delete</button>
                    </td>
                  </tr>";
        }
        ?>
    </table>

    <nav>
        <ul>
            <li><a href="index.html">Home</a></li>
            <li><a href="register.php">Register</a></li>
            <li><a href="admin.php">Admin</a></li>
            <li><a href="view_users.php">View Users</a></li>
            <li><a href="view_schedule.php">View Schedule</a></li>
            <li><a href="lab_tracker.php">Lab Tracker</a></li>
        </ul>
    </nav>
</body>
<script src="js/scripts.js"></script>
</html>
