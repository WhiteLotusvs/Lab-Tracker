<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Labs</title>
    <link rel="stylesheet" href="../styles.css">
</head>
<body>
    <div class="header">
        <h1>Edit Labs</h1>
    </div>
    <nav>
        <ul>
            <li><a href="../index.php">Home</a></li>
            <li><a href="../register.php">Register</a></li>
            <li><a href="../login.php">Login</a></li>
            <li><a href="../lab_tracker.php">Lab Tracker</a></li>
            <li><a href="admin.php">Admin</a></li>
        </ul>
    </nav>
    <form method="post" action="edit_labs.php">
        <label for="course_name">Course Name:</label>
        <input type="text" id="course_name" name="course_name" required><br>
        <label for="course_section">Course Section:</label>
        <input type="text" id="course_section" name="course_section" required><br>
        <label for="instructor_name">Instructor Name:</label>
        <input type="text" id="instructor_name" name="instructor_name" required><br>
        <label for="lab_time">Lab Time:</label>
        <input type="text" id="lab_time" name="lab_time" required><br>
        <button type="submit" name="add">Add Lab</button>
        <button type="submit" name="delete">Delete Lab</button>
    </form>

    <h2>Current Labs</h2>
    <table>
        <tr>
            <th>Course Name</th>
            <th>Course Section</th>
            <th>Instructor Name</th>
            <th>Lab Time</th>
            <th>Actions</th>
        </tr>
        <?php
        $file_path = __DIR__ . '/../data/labs.json';
        if (file_exists($file_path)) {
            $labs_content = file_get_contents($file_path);
            echo "<!-- File content: $labs_content -->"; // Debugging statement
            $labs = json_decode($labs_content, true);
            if (!is_array($labs)) {
                $labs = [];
            }
        } else {
            echo "File not found.";
            $labs = [];
        }

        foreach ($labs as $lab):
        ?>
        <tr>
            <td><?= $lab['course_name'] ?></td>
            <td><?= $lab['course_section'] ?></td>
            <td><?= $lab['instructor_name'] ?></td>
            <td><?= $lab['lab_time'] ?></td>
            <td>
                <form method="post" action="edit_labs.php">
                    <input type="hidden" name="course_name" value="<?= $lab['course_name'] ?>">
                    <button type="submit" name="delete">Delete</button>
                </form>
            </td>
        </tr>
        <?php endforeach; ?>

        <?php
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            if (isset($_POST['add'])) {
                $new_lab = array(
                    "course_name" => $_POST['course_name'],
                    "course_section" => $_POST['course_section'],
                    "instructor_name" => $_POST['instructor_name'],
                    "lab_time" => $_POST['lab_time']
                );
                $labs[] = $new_lab;
                file_put_contents($file_path, json_encode($labs));
                echo "<script>alert('Lab added successfully!');</script>";
            } elseif (isset($_POST['delete'])) {
                $labs = array_filter($labs, function($lab) {
                    return $lab['course_name'] !== $_POST['course_name'];
                });
                file_put_contents($file_path, json_encode($labs));
                echo "<script>alert('Lab deleted successfully!');</script>";
            }
        }
        ?>
    </table>
</body>
</html>
