<?php
$usersFile = 'data/users.json';
$users = file_exists($usersFile) ? json_decode(file_get_contents($usersFile), true) : [];
?>

<?php include('header.html'); ?>
<div class="container">
    <h1>View Users</h1>
    <table>
        <thead>
            <tr>
                <th>Edit</th>
                <th>Delete</th>
                <th>Username</th>
                <th>Student ID</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($users as $user): ?>
            <tr>
                <td><a href="edit_user.php?username=<?php echo $user['username']; ?>">Edit</a></td>
                <td><a href="delete_user.php?username=<?php echo $user['username']; ?>">Delete</a></td>
                <td><?php echo $user['username']; ?></td>
                <td><?php echo $user['studentID']; ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php include('footer.html'); ?>


