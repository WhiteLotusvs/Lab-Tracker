<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Lab Tracker</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <div class="header">
        <h1>Welcome to the Lab Tracker</h1>
    </div>
    <nav>
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="register.php">Register</a></li>
            <li><a href="login.php">Login</a></li>
            <li><a href="lab_tracker.php">Lab Tracker</a></li>
            <li><a href="admin/admin.php">Admin</a></li>
        </ul>
    </nav>
</body>
</html>
