function saveToLocalStorage(key, data) {
    localStorage.setItem(key, JSON.stringify(data));
}

function getFromLocalStorage(key) {
    return JSON.parse(localStorage.getItem(key)) || [];
}

function deleteFromLocalStorage(key, identifier, value) {
    let data = getFromLocalStorage(key);
    data = data.filter(item => item[identifier] !== value);
    saveToLocalStorage(key, data);
}
