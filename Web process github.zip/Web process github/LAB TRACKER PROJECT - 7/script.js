let timer;
let seconds = 0, minutes = 0, hours = 0;

function updateTime() {
    seconds++;
    if (seconds == 60) {
        seconds = 0;
        minutes++;
        if (minutes == 60) {
            minutes = 0;
            hours++;
        }
    }
    document.getElementById('timerDisplay').innerText = 
        (hours < 10 ? '0' + hours : hours) + ':' + 
        (minutes < 10 ? '0' + minutes : minutes) + ':' + 
        (seconds < 10 ? '0' + seconds : seconds);
}

document.getElementById('startButton').addEventListener('click', () => {
    clearInterval(timer);
    timer = setInterval(updateTime, 1000);
});

document.getElementById('stopButton').addEventListener('click', () => {
    clearInterval(timer);
});
