<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>View Schedule</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="header">
        <h1>Lab Schedule</h1>
    </div>
    <nav>
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="register.php">Register</a></li>
            <li><a href="login.php">Login</a></li>
            <li><a href="lab_tracker.php">Lab Tracker</a></li>
            <li><a href="admin.php">Admin</a></li>
        </ul>
    </nav>
    <h2>Active Lab Classes</h2>
    <table>
        <tr>
            <th>Course Name</th>
            <th>Course Section</th>
            <th>Instructor Name</th>
            <th>Lab Time</th>
        </tr>
        <?php
        $file_path = __DIR__ . '/data/labs.json';
        $labs = json_decode(file_get_contents($file_path), true);
        foreach ($labs as $lab) {
            echo "<tr>
                    <td>{$lab['course_name']}</td>
                    <td>{$lab['course_section']}</td>
                    <td>{$lab['instructor_name']}</td>
                    <td>{$lab['lab_time']}</td>
                  </tr>";
        }
        ?>
    </table>
</body>
</html>
