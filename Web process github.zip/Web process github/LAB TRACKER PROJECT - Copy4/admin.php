<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin</title>
    <link rel="stylesheet" href="../css/styles.css">
</head>
<body>
    <div class="header">
        <h1>Admin Panel</h1>
    </div>
    <nav>
        <ul>
            <li><a href="../index.php">Home</a></li>
            <li><a href="../register.php">Register</a></li>
            <li><a href="../login.php">Login</a></li>
            <li><a href="../lab_tracker.php">Lab Tracker</a></li>
            <li><a href="admin.php">Admin</a></li>
        </ul>
    </nav>
    <nav>
        <ul>
            <li><a href="view_users.php">View Users</a></li>
            <li><a href="view_schedule.php">View Schedule</a></li>
            <li><a href="edit_users.php">Edit Users</a></li>
            <li><a href="edit_labs.php">Edit Labs</a></li>
        </ul>
    </nav>
</body>
</html>
