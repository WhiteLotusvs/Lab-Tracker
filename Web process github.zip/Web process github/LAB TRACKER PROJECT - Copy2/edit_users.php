<?php
$usersFile = 'data/users.json';
$users = file_exists($usersFile) ? json_decode(file_get_contents($usersFile), true) : [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['delete'])) {
        $users = array_filter($users, function ($user) {
            return $user['username'] !== $_POST['username'];
        });
    } elseif (isset($_POST['edit'])) {
        foreach ($users as &$user) {
            if ($user['username'] === $_POST['old_username']) {
                $user['username'] = $_POST['username'];
                $user['studentID'] = $_POST['studentID'];
                break;
            }
        }
    }

    file_put_contents($usersFile, json_encode($users, JSON_PRETTY_PRINT));
    header('Location: edit_users.php');
    exit;
}
?>

<?php include('header.html'); ?>
<div class="container">
    <h1>Edit Users</h1>
    <form action="edit_users.php" method="post">
        <input type="hidden" name="old_username" value="">
        <label for="username">Username:</label>
        <input type="text" id="username" name="username" required>
        
        <label for="studentID">Student ID:</label>
        <input type="text" id="studentID" name="studentID" required>
        
        <input type="submit" name="edit" value="Edit User">
        <input type="submit" name="delete" value="Delete User">
    </form>
    <h2>Active Users</h2>
    <table>
        <thead>
            <tr>
                <th>Edit</th>
                <th>Delete</th>
                <th>Username</th>
                <th>Student ID</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($users as $user): ?>
            <tr>
                <td><button type="button" onclick="editUser('<?php echo $user['username']; ?>', '<?php echo $user['studentID']; ?>')">Edit</button></td>
                <td>
                    <form action="edit_users.php" method="post">
                        <input type="hidden" name="username" value="<?php echo $user['username']; ?>">
                        <input type="submit" name="delete" value="Delete">
                    </form>
                </td>
                <td><?php echo $user['username']; ?></td>
                <td><?php echo $user['studentID']; ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php include('footer.html'); ?>

<script>
function editUser(username, studentID) {
    document.querySelector('input[name="old_username"]').value = username;
    document.querySelector('input[name="username"]').value = username;
    document.querySelector('input[name="studentID"]').value = studentID;
}
</script>
