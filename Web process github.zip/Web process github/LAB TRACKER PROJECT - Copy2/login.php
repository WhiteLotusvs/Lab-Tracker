<?php
$usersFile = 'data/users.json';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $users = file_exists($usersFile) ? json_decode(file_get_contents($usersFile), true) : [];

    foreach ($users as $user) {
        if ($user['username'] === $_POST['username'] && password_verify($_POST['password'], $user['password']) && $user['studentID'] === $_POST['studentID']) {
            // Set session or cookies here for the logged-in user
            header('Location: dashboard.php'); // Redirect to the user's dashboard
            exit;
        }
    }
    echo 'Invalid username, password, or student ID';
}
?>

<?php include('header.html'); ?>
<div class="container">
    <h1>Login</h1>
    <form action="login.php" method="post">
        <label for="username">Username:</label>
        <input type="text" id="username" name="username" required>
        
        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required>
        
        <label for="studentID">Student ID:</label>
        <input type="text" id="studentID" name="studentID" required>
        
        <input type="submit" value="Login">
    </form>
</div>
<?php include('footer.html'); ?>
