<?php
$usersFile = 'data/users.json';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $users = file_exists($usersFile) ? json_decode(file_get_contents($usersFile), true) : [];

    $newUser = [
        'username' => $_POST['username'],
        'password' => password_hash($_POST['password'], PASSWORD_DEFAULT),
        'studentID' => $_POST['studentID']
    ];

    $users[] = $newUser;

    file_put_contents($usersFile, json_encode($users, JSON_PRETTY_PRINT));

    header('Location: index.php');
    exit;
}
?>

<?php include('header.html'); ?>
<div class="container">
    <h1>Register</h1>
    <form action="register.php" method="post">
        <label for="username">Username (6 letters):</label>
        <input type="text" id="username" name="username" pattern="[A-Za-z]{6}" title="Six letters only" required>
        
        <label for="password">Password (6 characters, 1 uppercase, 1 lowercase, 1 special character (*%#$!)):</label>
        <input type="password" id="password" name="password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[*%#$!]).{6,}" title="Must contain at least one number and one uppercase and lowercase letter, and one special character (*%#$!), and at least 6 or more characters" required>
        
        <label for="studentID">Student ID (7 digits):</label>
        <input type="text" id="studentID" name="studentID" pattern="\d{7}" title="Seven digits only" required>
        
        <input type="submit" value="Register">
    </form>
</div>
<?php include('footer.html'); ?>
