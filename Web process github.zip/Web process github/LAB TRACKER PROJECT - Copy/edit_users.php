<?php
session_start();

if (!isset($_SESSION['username']) || $_SESSION['role'] != 'admin') {
    header('Location: index.php');
    exit;
}

$usersFile = 'data/users.json';
$users = json_decode(file_get_contents($usersFile), true);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['add'])) {
        $newUser = [
            'username' => $_POST['username'],
            'password' => password_hash($_POST['password'], PASSWORD_DEFAULT),
            'studentId' => $_POST['studentId'],
            'role' => 'student'
        ];
        $users[] = $newUser;
    } elseif (isset($_POST['edit'])) {
        foreach ($users as &$user) {
            if ($user['username'] == $_POST['old_username']) {
                $user['username'] = $_POST['username'];
                $user['password'] = password_hash($_POST['password'], PASSWORD_DEFAULT);
                $user['studentId'] = $_POST['studentId'];
                break;
            }
        }
    } elseif (isset($_POST['delete'])) {
        $users = array_filter($users, function($user) {
            return $user['username'] != $_POST['username'];
        });
    }

    file_put_contents($usersFile, json_encode($users, JSON_PRETTY_PRINT));
    header('Location: edit_users.php');
    exit;
}
?>

<?php include('header.html'); ?>
<div class="container">
    <h1>Edit Users</h1>
    <form action="edit_users.php" method="post">
        <input type="hidden" name="old_username" value="">
        <label for="username">Username:</label>
        <input type="text" id="username" name="username" required>
        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required>
        <label for="studentId">Student ID:</label>
        <input type="number" id="studentId" name="studentId" required>
        <input type="submit" name="add" value="Add User">
        <input type="submit" name="edit" value="Edit User">
        <input type="submit" name="delete" value="Delete User">
    </form>
    <h2>Registered Users</h2>
    <table>
        <thead>
            <tr>
                <th>Edit</th>
                <th>Delete</th>
                <th>Username</th>
                <th>Password</th>
                <th>Student ID</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($users as $user): ?>
            <tr>
                <td><button type="button" onclick="editUser('<?php echo $user['username']; ?>', '<?php echo $user['password']; ?>', '<?php echo $user['studentId']; ?>')">Edit</button></td>
                <td>
                    <form action="edit_users.php" method="post">
                        <input type="hidden" name="username" value="<?php echo $user['username']; ?>">
                        <input type="submit" name="delete" value="Delete">
                    </form>
                </td>
                <td><?php echo $user['username']; ?></td>
                <td><?php echo $user['password']; ?></td>
                <td><?php echo $user['studentId']; ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php include('footer.html'); ?>

<script>
function editUser(username, password, studentId) {
    document.querySelector('input[name="old_username"]').value = username;
    document.querySelector('input[name="username"]').value = username;
    document.querySelector('input[name="password"]').value = password;
    document.querySelector('input[name="studentId"]').value = studentId;
}
</script>
