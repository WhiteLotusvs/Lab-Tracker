<?php
session_start();

if (!isset($_SESSION['username'])) {
    header('Location: index.php');
    exit;
}

$labs = json_decode(file_get_contents('data/labs.json'), true);
?>

<?php include('header.html'); ?>
<div class="container">
    <h1>Welcome to the Lab Tracker</h1>
    <p>Logged in as: <?php echo $_SESSION['username']; ?></p>
    <p><a href="logout.php">Logout</a></p>
    <div id="labs">
        <h2>Active Labs</h2>
        <ul>
            <?php foreach ($labs as $lab): ?>
                <li>
                    <strong><?php echo $lab['courseName']; ?></strong><br>
                    Section: <?php echo $lab['courseSection']; ?><br>
                    Instructor: <?php echo $lab['instructorName']; ?><br>
                    Time: <?php echo $lab['labTime']; ?><br>
                    <a href="join_lab.php?courseName=<?php echo $lab['courseName']; ?>">Join Lab</a>
                </li>
            <?php endforeach; ?>
        </ul>
    </div>
    <div id="timer"></div>
    <script>
    function updateTime() {
        const options = { timeZone: 'America/Los_Angeles', hour: '2-digit', minute: '2-digit', second: '2-digit' };
        const timeString = new Date().toLocaleTimeString([], options);
        document.getElementById('timer').innerText = `Pacific Time: ${timeString}`;
    }
    setInterval(updateTime, 1000);
    updateTime();
    </script>
</div>
<?php include('footer.html'); ?>
