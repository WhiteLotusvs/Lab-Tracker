<?php
session_start();

if (!isset($_SESSION['username']) || $_SESSION['username'] != 'admin') {
    header('Location: index.php');
    exit;
}
?>

<?php include('header.html'); ?>
<div class="container">
    <h1>Admin Panel</h1>
    <p><a href="logout.php">Logout</a></p>
    <div class="admin-forms">
        <div class="admin-form">
            <h2>Manage Users</h2>
            <p><a href="edit_users.php">Edit Users</a></p>
        </div>
        <div class="admin-form">
            <h2>Manage Labs</h2>
            <p><a href="edit_labs.php">Edit Labs</a></p>
        </div>
    </div>
</div>
<?php include('footer.html'); ?>
