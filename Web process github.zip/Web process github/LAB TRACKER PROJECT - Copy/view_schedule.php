<?php
$labsFile = 'data/labs.json';
$labs = file_exists($labsFile) ? json_decode(file_get_contents($labsFile), true) : [];
?>

<?php include('header.html'); ?>
<div class="container">
    <h1>View Schedule</h1>
    <table>
        <thead>
            <tr>
                <th>Course Name</th>
                <th>Course Section</th>
                <th>Instructor Name</th>
                <th>Lab Time</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($labs as $lab): ?>
            <tr>
                <td><?php echo $lab['courseName']; ?></td>
                <td><?php echo $lab['courseSection']; ?></td>
                <td><?php echo $lab['instructorName']; ?></td>
                <td><?php echo $lab['labTime']; ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php include('footer.html'); ?>
