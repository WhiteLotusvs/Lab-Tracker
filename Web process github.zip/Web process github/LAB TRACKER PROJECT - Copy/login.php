<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $studentId = $_POST['studentId'];

    $usersFile = 'data/users.json';
    $users = json_decode(file_get_contents($usersFile), true);

    foreach ($users as $user) {
        if ($user['username'] === $username && password_verify($password, $user['password']) && $user['studentId'] === $studentId) {
            $_SESSION['username'] = $username;
            $_SESSION['role'] = $user['role'];
            header('Location: lab_tracker.php');
            exit;
        }
    }

    echo 'Invalid username, password, or student ID';
}
?>

    echo 'Invalid username, password, or student ID';
}
?>
