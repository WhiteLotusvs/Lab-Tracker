<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $studentId = $_POST['studentId'];

    // Validate inputs
    if (!preg_match('/^[a-zA-Z]{6}$/', $username)) {
        die('Username must be 6 letters.');
    }
    if (!preg_match('/^(?=.*[A-Z])(?=.*[a-z])(?=.*[*%#$!]).{6,}$/', $password)) {
        die('Password must be at least 6 characters long and include 1 uppercase letter, 1 lowercase letter, and 1 special character (*%#$!).');
    }
    if (!preg_match('/^\d{7}$/', $studentId)) {
        die('Student ID must be 7 digits.');
    }

    $usersFile = 'data/users.json';
    $users = json_decode(file_get_contents($usersFile), true);

    // Check for existing username or student ID
    foreach ($users as $user) {
        if ($user['username'] === $username || $user['studentId'] === $studentId) {
            die('Username or Student ID already exists.');
        }
    }

    // Add new user
    $users[] = [
        'username' => $username,
        'password' => password_hash($password, PASSWORD_DEFAULT),
        'studentId' => $studentId,
        'role' => 'student'
    ];

    // Save to JSON file
    file_put_contents($usersFile, json_encode($users, JSON_PRETTY_PRINT));

    echo 'User registered successfully';
    header('Location: index.php');
    exit;
}
?>

<?php include('header.html'); ?>
<div class="container">
    <h1>Register</h1>
    <form id="registerForm" action="register.php" method="post">
        <label for="username">Username:</label>
        <input type="text" id="username" name="username" required>
        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required>
        <label for="studentId">Student ID:</label>
        <input type="number" id="studentId" name="studentId" required>
        <input type="submit" value="Register">
    </form>
    <p>Username requires: 6 letters only.</p>
    <p>Password requires: 6 characters, at least 1 uppercase, 1 lowercase, and 1 special character (*%#$!).</p>
    <p>Student ID: 7 digit numbers only.</p>
</div>
<?php include('footer.html'); ?>
