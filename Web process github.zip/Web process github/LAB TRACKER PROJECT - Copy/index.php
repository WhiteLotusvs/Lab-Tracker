<?php include('header.html'); ?>
<div class="container">
    <h1>Welcome to the Lab Tracker</h1>
    <form id="loginForm" action="login.php" method="post">
        <label for="username">Username:</label>
        <input type="text" id="username" name="username" required>
        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required>
        <label for="studentId">Student ID:</label>
        <input type="number" id="studentId" name="studentId" required>
        <input type="submit" value="Login">
    </form>
    <p>Don't have an account? <a href="register.php">Register here</a>.</p>
</div>
<?php include('footer.html'); ?>
