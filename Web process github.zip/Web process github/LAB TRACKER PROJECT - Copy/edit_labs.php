<?php
session_start();

if (!isset($_SESSION['username']) || $_SESSION['role'] != 'admin') {
    header('Location: index.php');
    exit;
}

$labsFile = 'data/labs.json';
$labs = json_decode(file_get_contents($labsFile), true);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['add'])) {
        $newLab = [
            'courseName' => $_POST['courseName'],
            'courseSection' => $_POST['courseSection'],
            'instructorName' => $_POST['instructorName'],
            'labTime' => $_POST['labTime']
        ];
        $labs[] = $newLab;
    } elseif (isset($_POST['edit'])) {
        foreach ($labs as &$lab) {
            if ($lab['courseName'] == $_POST['old_courseName'] && $lab['courseSection'] == $_POST['old_courseSection']) {
                $lab['courseName'] = $_POST['courseName'];
                $lab['courseSection'] = $_POST['courseSection'];
                $lab['instructorName'] = $_POST['instructorName'];
                $lab['labTime'] = $_POST['labTime'];
                break;
            }
        }
    } elseif (isset($_POST['delete'])) {
        $labs = array_filter($labs, function($lab) {
            return !($lab['courseName'] == $_POST['courseName'] && $lab['courseSection'] == $_POST['courseSection']);
        });
    }

    file_put_contents($labsFile, json_encode($labs, JSON_PRETTY_PRINT));
    header('Location: edit_labs.php');
    exit;
}
?>

<?php include('header.html'); ?>
<div class="container">
    <h1>Edit Labs</h1>
    <form action="edit_labs.php" method="post">
        <input type="hidden" name="old_courseName" value="">
        <input type="hidden" name="old_courseSection" value="">
        <label for="courseName">Course Name:</label>
        <input type="text" id="courseName" name="courseName" required>
        <label for="courseSection">Course Section Code:</label>
        <input type="text" id="courseSection" name="courseSection" required>
        <label for="instructorName">Instructor's Name:</label>
        <input type="text" id="instructorName" name="instructorName" required>
        <label for="labTime">Lab Class Time:</label>
        <input type="text" id="labTime" name="labTime" required>
        <input type="submit" name="add" value="Add Lab">
        <input type="submit" name="edit" value="Edit Lab">
        <input type="submit" name="delete" value="Delete Lab">
    </form>
    <h2>Active Labs</h2>
    <table>
        <thead>
            <tr>
                <th>Edit</th>
                <th>Delete</th>
                <th>Course Name</th>
                <th>Course Section</th>
                <th>Instructor Name</th>
                <th>Lab Time</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($labs as $lab): ?>
            <tr>
                <td><button type="button" onclick="editLab('<?php echo $lab['courseName']; ?>', '<?php echo $lab['courseSection']; ?>', '<?php echo $lab['instructorName']; ?>', '<?php echo $lab['labTime']; ?>')">Edit</button></td>
                <td>
                    <form action="edit_labs.php" method="post">
                        <input type="hidden" name="courseName" value="<?php echo $lab['courseName']; ?>">
                        <input type="hidden" name="courseSection" value="<?php echo $lab['courseSection']; ?>">
                        <input type="submit" name="delete" value="Delete">
                    </form>
                </td>
                <td><?php echo $lab['courseName']; ?></td>
                <td><?php echo $lab['courseSection']; ?></td>
                <td><?php echo $lab['instructorName']; ?></td>
                <td><?php echo $lab['labTime']; ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php include('footer.html'); ?>

<script>
function editLab(courseName, courseSection, instructorName, labTime) {
    document.querySelector('input[name="old_courseName"]').value = courseName;
    document.querySelector('input[name="old_courseSection"]').value = courseSection;
    document.querySelector('input[name="courseName"]').value = courseName;
    document.querySelector('input[name="courseSection"]').value = courseSection;
    document.querySelector('input[name="instructorName"]').value = instructorName;
    document.querySelector('input[name="labTime"]').value = labTime;
}
</script>
