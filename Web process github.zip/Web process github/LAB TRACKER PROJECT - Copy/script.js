document.addEventListener('DOMContentLoaded', function() {
    if (document.getElementById('loginForm')) {
        document.getElementById('loginForm').addEventListener('submit', loginUser);
    }
    if (document.getElementById('registerForm')) {
        document.getElementById('registerForm').addEventListener('submit', registerUser);
    }
});

function loginUser(e) {
    e.preventDefault();

    let username = document.getElementById('username').value;
    let password = document.getElementById('password').value;
    let studentId = document.getElementById('studentId').value;

    let users = JSON.parse(localStorage.getItem('users')) || [];

    let user = users.find(user => user.username === username && user.password === password && user.studentId === studentId);

    if (user) {
        alert('Login successful');
        window.location.href = 'lab_tracker.php';
    } else {
        alert('Invalid username, password, or student ID');
    }
}

function registerUser(e) {
    e.preventDefault();

    let username = document.getElementById('username').value;
    let password = document.getElementById('password').value;
    let studentId = document.getElementById('studentId').value;

    let users = JSON.parse(localStorage.getItem('users')) || [];

    users.push({ username, password, studentId });

    localStorage.setItem('users', JSON.stringify(users));

    alert('User registered successfully');
    window.location.href = 'index.php';
}
