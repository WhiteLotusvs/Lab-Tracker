#include <algorithm>
#include <iostream>
#include <map>
#include <string>
#include <vector>

class Student {
public:
    std::string firstName;
    std::string lastName;
    int studentID;

    Student(int id, std::string fName, std::string lName)
        : firstName(fName), lastName(lName), studentID(id) {}
};

class LabSession {
    
};

int main() {
    // Create an instance of Student with ID 1, first name "John", and last name "Doe"
    Student s1(1, "John", "Doe");
    std::cout << "Student ID: " << s1.studentID << "\n";
    std::cout << "First Name: " << s1.firstName << "\n";
    std::cout << "Last Name: " << s1.lastName << "\n";
    return 0;
}
