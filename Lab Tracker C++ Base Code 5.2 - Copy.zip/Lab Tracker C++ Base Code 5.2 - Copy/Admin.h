#pragma once
#include "User.h"
/*
* this file is code for admin use things
    */

class Admin : public User {
public:
    Admin(const std::string& user, const std::string& pass, const std::string& fName, const std::string& lName, const std::string& id);
    void displayInfo() const override;
};
