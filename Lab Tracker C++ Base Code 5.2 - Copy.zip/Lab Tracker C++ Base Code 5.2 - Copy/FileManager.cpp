#include "FileManager.h"
#include <fstream>

void FileManager::saveUsers(const std::vector<User*>& users) {
    std::ofstream out("users.dat", std::ios::binary);
    for (auto user : users) {
        // Serialize user data
        (void)user; //
    }
    out.close(); 
}

void FileManager::loadUsers(std::vector<User*>& users) {
    std::ifstream in("users.dat", std::ios::binary);
    while (in) {
        // Deserialize user data
    // loop until end of file
    }
    in.close(); 
}

void FileManager::saveSessions(const std::vector<LabSession>& sessions) {
    std::ofstream out("sessions.dat", std::ios::binary); // 
    // Example serialization logic
    out.close();
}

void FileManager::loadSessions(std::vector<LabSession>& sessions) {
    std::ifstream in("sessions.dat", std::ios::binary);
    // Example deserialization logic
    in.close();
}
