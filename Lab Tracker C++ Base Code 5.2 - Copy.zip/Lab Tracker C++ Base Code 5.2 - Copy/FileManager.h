#pragma once
#include "User.h"
#include "LabSession.h"
#include <vector>

class FileManager {
public:
    static void saveUsers(const std::vector<User*>& users);
    static void loadUsers(std::vector<User*>& users);
    static void saveSessions(const std::vector<LabSession>& sessions);
    static void loadSessions(std::vector<LabSession>& sessions); // Note: sessions is passed by reference
};
