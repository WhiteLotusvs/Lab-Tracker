#pragma once
#include "LabManager.h"

class Menu {
public:
    static int displayMainMenu();
    static bool processUserChoice(int choice, LabManager& manager);
};
