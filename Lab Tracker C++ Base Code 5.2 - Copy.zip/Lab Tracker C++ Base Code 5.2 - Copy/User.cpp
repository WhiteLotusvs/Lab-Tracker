#include "User.h"
#include <iostream>

User::User(const std::string& user, const std::string& pass, const std::string& fName, const std::string& lName, const std::string& id)
    : username(user), password(pass), firstName(fName), lastName(lName), userID(id) {}

bool User::authenticate(const std::string& user, const std::string& pass) const {
    return username == user && password == pass;
} // // Return true if both username and password match

std::string User::getUserID() const {
    return userID;
}

std::string User::getUsername() const {
    return username;
}

Student::Student(const std::string& user, const std::string& pass, const std::string& fName, const std::string& lName, const std::string& id)
    : User(user, pass, fName, lName, id), hoursSpent(0) {}

void Student::logHours(float hours) {
    hoursSpent += hours;
}

void Student::displayInfo() const {
    std::cout << "Student: " << firstName << " " << lastName << " [" << userID << "], Hours Spent: " << hoursSpent << std::endl;
}

float Student::getHoursSpent() const {
    return hoursSpent;
}
