#include "LabSession.h"
#include <iostream>

LabSession::LabSession(const std::string& name, const std::string& section, const std::string& link)
    : sessionName(name), sectionNumber(section), meetLink(link) {}
// If the student is not already in the map, add them with 0 hours
void LabSession::addStudent(const std::string& userID) {
    if (studentHours.find(userID) == studentHours.end()) {
        studentHours[userID] = 0; // Initialize hours to 0
    }
}
 // If the student is found in the map, add the recorded hours to their total
void LabSession::recordSessionTime(const std::string& userID, float hours) {
    if (studentHours.find(userID) != studentHours.end()) {
        studentHours[userID] += hours;
    }
}

std::string LabSession::getSessionName() const {
    return sessionName;
}

std::string LabSession::getMeetLink() const {
    return meetLink;
}
