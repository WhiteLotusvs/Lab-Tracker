#include "Menu.h"
#include "LabManager.h"

int main() {
    LabManager labManager;
    labManager.loadAllData();

    bool running = true;
    while (running) {
        int choice = Menu::displayMainMenu();
        running = Menu::processUserChoice(choice, labManager);
    }

    labManager.saveAllData();
    return 0;
}
