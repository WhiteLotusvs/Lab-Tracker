#pragma once
#include <string>

class User {
protected:
    std::string username;
    std::string password;
    std::string firstName;
    std::string lastName;
    std::string userID;

public:
    User(const std::string& user, const std::string& pass, const std::string& fName, const std::string& lName, const std::string& id);
    virtual ~User() {}

    virtual bool authenticate(const std::string& user, const std::string& pass) const;
    virtual void displayInfo() const = 0;  // Pure virtual method to display user information, to be implemented by derived classes
    std::string getUsername() const;
    std::string getUserID() const;
};

class Student : public User {
private:
    float hoursSpent;

public:
    Student(const std::string& user, const std::string& pass, const std::string& fName, const std::string& lName, const std::string& id);
    void logHours(float hours);
    void displayInfo() const override;
    float getHoursSpent() const;
};
