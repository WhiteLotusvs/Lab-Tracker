#pragma once
#include <string>
#include <map>

class LabSession {
private:
    std::string sessionName;
    std::string sectionNumber;
    std::string meetLink;
    std::map<std::string, float> studentHours; // key: userID, value: hours.Map to store student IDs and their recorded hours

public:
    LabSession(const std::string& name, const std::string& section, const std::string& link);
    void addStudent(const std::string& userID);
    void recordSessionTime(const std::string& userID, float hours);
    std::string getSessionName() const;
    std::string getMeetLink() const;
};
