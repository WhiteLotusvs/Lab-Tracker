#include "Menu.h"
#include <iostream>

int Menu::displayMainMenu() {
    std::cout << "1. Login\n2. Exit\nEnter your choice: ";
    int choice;
    std::cin >> choice;
    return choice;
}
// Process the user's choice and perform the corresponding action
bool Menu::processUserChoice(int choice, LabManager& manager) {
    switch (choice) {
        case 1: {
            std::string username, password;
            std::cout << "Enter username: ";
            std::cin >> username;
            std::cout << "Enter password: ";
            std::cin >> password;
            User* user = manager.authenticateUser(username, password);
            if (user) {
                std::cout << "Login successful.\n";
                // Additional logic for user session
            } else {
                std::cout << "Login failed.\n";
            }
            break;
        }
        case 2:
            return false;
        default:
            std::cout << "Invalid option. Please try again.\n";
            break;
    }
    return true;
}
