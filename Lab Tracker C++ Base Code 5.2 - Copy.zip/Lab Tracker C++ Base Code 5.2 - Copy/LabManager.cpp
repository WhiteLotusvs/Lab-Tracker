#include "LabManager.h"
#include "FileManager.h"

LabManager::~LabManager() {
    for (auto user : users) {
        delete user;
    }
}

void LabManager::addUser(User* user) {
    users.push_back(user); // Add the user to the vector
}

void LabManager::addSession(const LabSession& session) {
    sessions.push_back(session); // 
}

User* LabManager::authenticateUser(const std::string& username, const std::string& password) {
    for (auto user : users) {
        if (user->authenticate(username, password)) {
            return user; // If user authentication is successful, return the user
        }
    }
    return nullptr; // Return nullptr if authentication fails
}
// Method to record attendance for a user in a specific session. If the session name matches, record the session time for the user
void LabManager::recordAttendance(const std::string& userID, const std::string& sessionName, float hours) {
    for (auto& session : sessions) {
        if (session.getSessionName() == sessionName) {
            session.recordSessionTime(userID, hours);
        }
    }
}
// Method to save all user and session data using FileManager
void LabManager::saveAllData() {
    FileManager::saveUsers(users);
    FileManager::saveSessions(sessions);
}

void LabManager::loadAllData() {
    FileManager::loadUsers(users);
    FileManager::loadSessions(sessions);
}
