#pragma once
#include "LabSession.h"
#include "User.h"
#include <vector>

class LabManager {
private:
    std::vector<User*> users; // Vector to store pointers to User objects
    std::vector<LabSession> sessions; // Vector to store LabSession objects

public:
    ~LabManager(); // Destructor to clean up dynamically allocated User objects.method to authenticate a User based on username and password
    void addUser(User* user);
    void addSession(const LabSession& session);
    User* authenticateUser(const std::string& username, const std::string& password);
    void recordAttendance(const std::string& userID, const std::string& sessionName, float hours);
    void saveAllData();
    void loadAllData();
};
