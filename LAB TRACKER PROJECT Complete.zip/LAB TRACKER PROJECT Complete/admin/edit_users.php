<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Users</title>
    <link rel="stylesheet" href="../styles.css">
</head>
<body>
    <div class="header">
        <h1>Edit Users</h1>
    </div>
    <nav>
        <ul>
            <li><a href="../index.php">Home</a></li>
            <li><a href="../register.php">Register</a></li>
            <li><a href="../login.php">Login</a></li>
            <li><a href="../lab_tracker.php">Lab Tracker</a></li>
            <li><a href="../admin.php">Admin</a></li>
        </ul>
    </nav>
    <form method="post" action="edit_users.php">
        <label for="username">Username:</label>
        <input type="text" id="username" name="username"><br>
        <label for="password">Password:</label>
        <input type="password" id="password" name="password"><br>
        <label for="student_id">Student ID:</label>
        <input type="text" id="student_id" name="student_id"><br>
        <button type="submit" name="add">Add User</button>
        <button type="submit" name="delete">Delete User</button>
    </form>

    <h2>Current Users</h2>
    <table>
        <tr>
            <th>Username</th>
            <th>Password</th>
            <th>Student ID</th>
            <th>Actions</th>
        </tr>
        <?php
        $file_path = __DIR__ . '/../data/users.json';
        $users = json_decode(file_get_contents($file_path), true);
        foreach ($users as $user) {
            echo "<tr>
                    <td>{$user['username']}</td>
                    <td>{$user['password']}</td>
                    <td>{$user['student_id']}</td>
                    <td>
                        <form method='post' action='edit_users.php'>
                            <input type='hidden' name='username' value='{$user['username']}'>
                            <button type='submit' name='delete'>Delete</button>
                        </form>
                    </td>
                  </tr>";
        }

        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            if (isset($_POST['add'])) {
                $new_user = array("username" => $_POST['username'], "password" => $_POST['password'], "student_id" => $_POST['student_id']);
                array_push($users, $new_user);
                file_put_contents($file_path, json_encode($users));
                echo "<script>alert('User added successfully!');</script>";
            } elseif (isset($_POST['delete'])) {
                $users = array_filter($users, function($user) {
                    return $user['username'] !== $_POST['username'];
                });
                file_put_contents($file_path, json_encode($users));
                echo "<script>alert('User deleted successfully!');</script>";
            }
        }
        ?>
    </table>
</body>
</html>
