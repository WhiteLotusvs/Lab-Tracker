<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>View Users</title>
    <link rel="stylesheet" href="../styles.css">
</head>
<body>
    <div class="header">
        <h1>View Users</h1>
    </div>
    <nav>
        <ul>
            <li><a href="../index.php">Home</a></li>
            <li><a href="../register.php">Register</a></li>
            <li><a href="../login.php">Login</a></li>
            <li><a href="../lab_tracker.php">Lab Tracker</a></li>
            <li><a href="admin.php">Admin</a></li>
        </ul>
    </nav>
    <h2>Registered Users</h2>
    <table>
        <tr>
            <th>Username</th>
            <th>Actions</th>
        </tr>
        <?php
        $file_path = __DIR__ . '/../data/users.json';
        if (file_exists($file_path)) {
            $users_content = file_get_contents($file_path);
            echo "<!-- File content: $users_content -->"; // Debugging statement
            $users = json_decode($users_content, true);
            if (!is_array($users)) {
                $users = [];
            }
        } else {
            echo "File not found.";
            $users = [];
        }

        foreach ($users as $user):
        ?>
        <tr>
            <td><?= $user['username'] ?></td>
            <td>
                <form method="post" action="view_users.php">
                    <input type="hidden" name="username" value="<?= $user['username'] ?>">
                    <button type="submit" name="delete">Delete</button>
                </form>
            </td>
        </tr>
        <?php endforeach; ?>

        <?php
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            if (isset($_POST['delete'])) {
                $users = array_filter($users, function($user) {
                    return $user['username'] !== $_POST['username'];
                });
                file_put_contents($file_path, json_encode($users));
                echo "<script>alert('User deleted successfully!');</script>";
            }
        }
        ?>
    </table>
</body>
</html>
