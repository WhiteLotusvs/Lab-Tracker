<?php
function validatePassword($password) {
    $regex = "/^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{6,20}$/";
    return preg_match($regex, $password);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    if (!validatePassword($password)) {
        echo "<script>alert('Password does not meet the requirements.');</script>";
    } else {
        $file_path = __DIR__ . '/data/users.json';
        if (file_exists($file_path)) {
            $users = json_decode(file_get_contents($file_path), true);
            foreach ($users as $user) {
                if ($user['username'] === $username && $user['password'] === $password) {
                    header("Location: admin/view_schedule.php"); // Redirect to the schedule page after login
                    exit;
                }
            }
        }
        echo "<script>alert('Invalid username or password.');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="header">
        <h1>Login</h1>
    </div>
    <nav>
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="register.php">Register</a></li>
            <li><a href="login.php">Login</a></li>
            <li><a href="lab_tracker.php">Lab Tracker</a></li>
            <li><a href="admin/admin.php">Admin</a></li>
        </ul>
    </nav>
    <form method="post" action="login.php">
        <label for="username">Username:</label>
        <input type="text" id="username" name="username" required><br>
        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required><br>
        <button type="submit">Login</button>
    </form>
</body>
</html>
