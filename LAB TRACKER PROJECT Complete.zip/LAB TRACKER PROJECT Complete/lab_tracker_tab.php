<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Lab Tracker</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <h1>Lab Tracker Timer</h1>
    <button id="startButton">Start Timer</button>
    <div id="timerDisplay">00:00:00</div>
    <button id="stopButton">Stop Timer</button>

    <nav>
        <ul>
            <li><a href="index.html">Home</a></li>
            <li><a href="register.php">Register</a></li>
            <li><a href="admin.php">Admin</a></li>
            <li><a href="view_users.php">View Users</a></li>
            <li><a href="view_schedule.php">View Schedule</a></li>
            <li><a href="lab_tracker.php">Lab Tracker</a></li>
        </ul>
    </nav>
</body>
<script src="js/scripts.js"></script>
</html>
