#include "main.h"

// Validation class implementation
bool Validation::isValidUsername(const std::string& username) {
    return !username.empty();
}

bool Validation::isValidPassword(const std::string& password) {
    return !password.empty();
}

bool Validation::isValidStudentID(const std::string& studentID) {
    return studentID.length() == 7 && std::all_of(studentID.begin(), studentID.end(), ::isdigit);
}

// User class implementation
User::User() : username(""), password(""), studentID("") {}

User::User(const std::string& username, const std::string& password, const std::string& studentID) 
    : username(username), password(password), studentID(studentID) {}

std::string User::getUsername() const {
    return username;
}

std::string User::getPassword() const {
    return password;
}

std::string User::getStudentID() const {
    return studentID;
}

// FileManager class implementation
void FileManager::saveData(const std::string& filename, const std::vector<User>& users) {
    std::ofstream file(filename);
    for (const auto& user : users) {
        file << user.getUsername() << " " << user.getPassword() << " " << user.getStudentID() << std::endl;
    }
}

std::vector<User> FileManager::loadData(const std::string& filename) {
    std::ifstream file(filename);
    std::vector<User> users;
    std::string username, password, studentID;
    while (file >> username >> password >> studentID) {
        users.emplace_back(username, password, studentID);
    }
    return users;
}

// LabSession class implementation
LabSession::LabSession() : labName(""), labDate("") {}

LabSession::LabSession(const std::string& labName, const std::string& labDate) 
    : labName(labName), labDate(labDate) {}

std::string LabSession::getLabName() const {
    return labName;
}

std::string LabSession::getLabDate() const {
    return labDate;
}

// LabManager class implementation
LabManager::LabManager() {}

void LabManager::loadAllData() {
    users = FileManager::loadData("users.txt");
    // Load lab sessions similarly if needed
}

void LabManager::saveAllData() {
    FileManager::saveData("users.txt", users);
    // Save lab sessions similarly if needed
}

void LabManager::addUser(const User& user) {
    users.push_back(user);
}

void LabManager::addLabSession(const LabSession& labSession) {
    labSessions.push_back(labSession);
}

// Menu class implementation
int Menu::displayMainMenu() {
    int choice;
    std::cout << "1. Login\n2. Exit\n";
    std::cin >> choice;
    return choice;
}

bool Menu::processUserChoice(int choice, LabManager& labManager) {
    switch (choice) {
    case 1: {
        std::string username, password, studentID;
        std::cout << "Enter username: ";
        std::cin >> username;
        std::cout << "Enter password: ";
        std::cin >> password;
        std::cout << "Enter student ID (7 digits): ";
        std::cin >> studentID;
        if (Validation::isValidUsername(username) && 
            Validation::isValidPassword(password) && 
            Validation::isValidStudentID(studentID)) {
            labManager.addUser(User(username, password, studentID));
            std::cout << "Login successful!\n";
        } else {
            std::cout << "Invalid credentials.\n";
        }
        break;
    }
    case 2:
        return false;
    default:
        std::cout << "Invalid choice. Please try again.\n";
    }
    return true;
}

// main function
int main() {
    LabManager labManager;
    labManager.loadAllData();

    bool running = true;
    while (running) {
        int choice = Menu::displayMainMenu();
        running = Menu::processUserChoice(choice, labManager);
    }

    labManager.saveAllData();
    return 0;
}

