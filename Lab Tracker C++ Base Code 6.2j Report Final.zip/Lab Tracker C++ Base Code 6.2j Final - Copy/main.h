#ifndef MAIN_H
#define MAIN_H

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <iomanip>
#include <algorithm> // Required for std::all_of

class Validation {
public:
    static bool isValidUsername(const std::string& username);
    static bool isValidPassword(const std::string& password);
    static bool isValidStudentID(const std::string& studentID);
};

class User {
public:
    User();
    User(const std::string& username, const std::string& password, const std::string& studentID);
    std::string getUsername() const;
    std::string getPassword() const;
    std::string getStudentID() const;

private:
    std::string username;
    std::string password;
    std::string studentID;
};

class FileManager {
public:
    static void saveData(const std::string& filename, const std::vector<User>& users);
    static std::vector<User> loadData(const std::string& filename);
};

class LabSession {
public:
    LabSession();
    LabSession(const std::string& labName, const std::string& labDate);
    std::string getLabName() const;
    std::string getLabDate() const;

private:
    std::string labName;
    std::string labDate;
};

class LabManager {
public:
    LabManager();
    void loadAllData();
    void saveAllData();
    void addUser(const User& user);
    void addLabSession(const LabSession& labSession);

private:
    std::vector<User> users;
    std::vector<LabSession> labSessions;
};

class Menu {
public:
    static int displayMainMenu();
    static bool processUserChoice(int choice, LabManager& labManager);
};

#endif // MAIN_H
