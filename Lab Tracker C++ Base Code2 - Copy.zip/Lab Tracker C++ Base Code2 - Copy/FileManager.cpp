#include "FileManager.h"
#include <fstream>
/*
* Loads data from a file into a vector of Student objects.
* manages files for the student
  */
void FileManager::save(const std::vector<Student>& students) {
  std::ofstream out("students.dat", std::ios::binary); // Open the file in binary mode
  for (const auto& student : students) {
    out.write((const char*)&student, sizeof(Student));
  }
  out.close(); // close the file
}

void FileManager::load(std::vector<Student>& students) {
  Student student;
  std::ifstream in("students.dat", std::ios::binary); // Open the file in binary mode
  while (in.read((char*)&student, sizeof(Student))) {
    students.push_back(student); // Add the student to the vector
  }
  in.close();
}
