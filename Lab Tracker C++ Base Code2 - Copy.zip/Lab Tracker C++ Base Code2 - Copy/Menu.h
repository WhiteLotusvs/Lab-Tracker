#pragma once
#include <string>

class Menu {
public:
  static int mainMenu();
  static std::string getStudentID();
  static float getHours();
};
