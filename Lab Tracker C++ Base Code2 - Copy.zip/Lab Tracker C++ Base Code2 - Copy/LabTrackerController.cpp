#include "LabTrackerController.h"
#include "FileManager.h"
/*
* this file is for the controller
* it is responsible for the logic behind lab tracking
  */
void LabTrackerController::addStudent(const Student& student) {
  students.push_back(student); // Add the student to the vector
}

void LabTrackerController::updateHours(const std::string& studentID, float hours) {
  for (auto& student : students) {
    if (student.studentID == studentID) {
      student.logHours(hours); // Update the hours for the student
      break; // if the student is found the loop is broken
    }
  }
}

void LabTrackerController::saveData() {
  FileManager::save(students); // Save the data to a file
}

void LabTrackerController::loadData() {
  FileManager::load(students); // Load the data from a file
}
