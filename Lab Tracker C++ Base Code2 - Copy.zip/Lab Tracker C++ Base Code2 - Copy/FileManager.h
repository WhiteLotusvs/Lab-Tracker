#pragma once
#include <vector>
#include "Student.h"

class FileManager {
public:
  static void save(const std::vector<Student>& students); // Save students to a file
  static void load(std::vector<Student>& students); // Note: This function is not const
};
