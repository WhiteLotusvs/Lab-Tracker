#include "Student.h"

Student::Student() : hoursSpent(0.0f) {} // 0.0f is a float literal/ hours spent is set to 0.0

void Student::logHours(float hours) {
  hoursSpent += hours; // Add the hours to the total hours spent
}
