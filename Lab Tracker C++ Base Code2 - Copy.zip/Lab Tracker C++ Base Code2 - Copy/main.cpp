#include "LabTrackerController.h"
#include "Menu.h"
#include <iostream>

int main() {
  LabTrackerController controller; // Create a controller object
  controller.loadData();

  bool running = true; // Flag to control the main loop
  while (running) {
    int choice = Menu::mainMenu(); // while the flag is true the main menu is displayed
    switch (choice) {
      case 1: {
        std::string id = Menu::getStudentID(); // get the student id
        float hours = Menu::getHours(); // get the hours
        controller.updateHours(id, hours); // update the hours
        break;
      }
      case 2:
        // Admin menu logic
        break;
      case 3: 
        running = false; // set the flag to false to exit the loop
        break; 
      default:
        std::cout << "Invalid option, please try again." << std::endl; //
    }
  }

  controller.saveData(); // Save the data before exiting
  return 0;
}
