#pragma once
#include <string>

class Student {
public:
  std::string studentID;
  float hoursSpent; // on lab

  Student();
  void logHours(float hours); // Log hours spent on the lab
};
