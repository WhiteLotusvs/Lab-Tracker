#include "Menu.h"
#include <iostream>

int Menu::mainMenu() {
  int choice;
  std::cout << "1. Log Hours\n2. Admin\n3. Exit\nEnter choice: "; // Display the main menu
  std::cin >> choice;
  return choice;
}

std::string Menu::getStudentID() {
  std::string id; 
  std::cout << "Enter student ID (7 digits): "; // Get the student ID
  std::cin >> id;
  return id;
}

float Menu::getHours() {
  float hours; 
  std::cout << "Enter hours: "; // Get the hours
  std::cin >> hours;
  return hours;
}
