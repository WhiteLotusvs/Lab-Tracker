#pragma once
#include <vector>
#include "Student.h"

class LabTrackerController {
  std::vector<Student> students;

public:
  void addStudent(const Student& student);
  void updateHours(const std::string& studentID, float hours);
  void saveData();
  void loadData(); // Note: This function is not const
};
