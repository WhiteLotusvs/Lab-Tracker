#include <fstream>
#include <iostream>
#include <string>
#include <vector>

using namespace std;

/*
* step 1
  */
class Student { 
public:
  string studentID; 
  float hoursSpent;

  Student() : hoursSpent(0.0f) {} // Default constructor

  void logHours(float hours) { hoursSpent += hours; }
}; // End of class Student

class FileManager { 
public:
  static void save(const vector<Student> &students) {
    ofstream out("students.dat", ios::binary);
    for (const auto &student : students) {
      out.write((const char *)&student, sizeof(Student)); // Write student object to file
    }
    out.close(); // Close file
  }

  static void load(vector<Student> &students) {
    Student student;
    ifstream in("students.dat", ios::binary); // Open file for reading
    while (in.read((char *)&student,  sizeof(Student))) {
      students.push_back(student); // Add student object to vector
    }
    in.close(); // Close file
  } 
};

// Controller
class LabTrackerController {
  vector<Student> students; // Vector of Student objects

public:
  void addStudent(const Student &student) { students.push_back(student); } // Add student to vector. student is a reference to a Student object.

  void updateHours(const string &studentID, float hours) {
    for (auto &student : students) {
      if (student.studentID == studentID) {
        student.logHours(hours); // Log hours spent by student
        break; // exit loop after updating hours
      }
    }
  }

  void saveData() { FileManager::save(students); }

  void loadData() { FileManager::load(students); }
}; // End of class LabTrackerController

// View
class Menu {
public:
  static int mainMenu() {
    int choice;
    cout << "1. Log Hours\n2. Admin\n3. Exit\nEnter choice: ";
    cin >> choice;
    return choice; // Return user's choice
  }

  static string getStudentID() {
    string id;
    cout << "Enter student ID (7 digits): ";
    cin >> id;
    return id; // what kind of ID?
  }

  static float getHours() {
    float hours;
    cout << "Enter hours: ";
    cin >> hours;
    return hours;
  }
}; // need an interanl clock system?

// Main Application
int main() {
  LabTrackerController controller;
  controller.loadData(); // Load data from file

  bool running = true; // Flag to control program loop
  while (running) {
    int choice = Menu::mainMenu(); // Display main menu and get user's choice
    switch (choice) {
    case 1: {
      string id = Menu::getStudentID(); // Get student ID
      float hours = Menu::getHours(); // Get hours from user
      controller.updateHours(id, hours); // Update hours for student with given ID
      break;
    }
    case 2:
      // Admin menu logic
      break;
    case 3:
      running = false; // Exit program
      break;
    default:
      cout << "Invalid option, please try again." << endl; // Invalid option
    }
  }

  controller.saveData(); // Save data to file
  return 0;
}
