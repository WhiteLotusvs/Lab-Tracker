#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <stdexcept>

using namespace std;

class User {
protected:
    string firstName, lastName, username; // Member variables to store user details
    int userID; // Member variable to store user ID
public:
    User(string fname, string lname, int id) : firstName(fname), lastName(lname), userID(id) {
        username = firstName + "." + lastName;
    }
    virtual void displayInfo() = 0;
    virtual ~User() {}
};

class NormalUser : public User {
public:
    NormalUser(string fname, string lname, int id) : User(fname, lname, id) {}

// Override the displayInfo method to display user information
    void displayInfo() override {
        cout << "User Info: " << endl;
        cout << "First Name: " << firstName << endl;
        cout << "Last Name: " << lastName << endl;
        cout << "Username: " << username << endl;
        cout << "UserID: " << userID << endl;
    }
};

int main() {
    vector<User*> users;
    users.push_back(new NormalUser("John", "Doe", 1));
    users.push_back(new NormalUser("Jane", "Smith", 2));
    // Iterate through the vector and display information for each user

    for(User* user : users) {
        user->displayInfo();
        delete user;  // Delete the user object to free memory
    }

    return 0;
}
